from je_editor import *

start_editor()
